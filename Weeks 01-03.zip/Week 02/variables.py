# Data type of String
name = "David"

# Data type of Integer
age = 21

# Data type of Float
height = 1.70

# Data type of Boolean
online = True

print(name, age, height, online)
print("Welcome", name, "you are", age, "your height is", height, "online:", online)

score = 5
print("Score:", score)
# The next like is exactly like ---> score = score + 5
score += 5
print("Score:", score)
