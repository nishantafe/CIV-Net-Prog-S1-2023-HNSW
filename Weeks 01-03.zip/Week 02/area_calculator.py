"""This program will calculate the area of a rectangle"""
width = int(input("Enter the width in metres: "))
height = int(input("Enter the height in metres: "))
area = width * height

print("The area is", area, "square metres")
