name = input("Enter your name: ")
print("Welcome", name)

score = int(input("Enter your current score: "))
score += 10
print("Hey", name, "we'll give you bonus of 10")
print("Score:", score)
