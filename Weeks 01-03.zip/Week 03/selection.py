result = 100
if result < 50:
    print("The result is less than 50")
else:
    print("The result is greater thank 50")
