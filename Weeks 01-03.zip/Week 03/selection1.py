result = 50
if result >= 50:
    print("Well done")
else:
    print("Unfortunately you didn't pass")
