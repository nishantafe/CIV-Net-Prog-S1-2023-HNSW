if 10 < 5:
    print("False, this block will not be executed")
if 0 < 5:
    print("True, this block will be executed")

if 0 > 3:
    print("True, this block will be executed")
else:
    print("If the if fails, execute this")
