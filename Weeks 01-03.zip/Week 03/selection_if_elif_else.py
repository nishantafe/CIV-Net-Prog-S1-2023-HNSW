if 10 < 5:
    print("False, this block will not be executed")
elif 0 < 5:
    print("True, this block will be executed")
elif 0 > 3:
    print("True, this block will not be executed")
else:
    print("If the if fails, execute this")
