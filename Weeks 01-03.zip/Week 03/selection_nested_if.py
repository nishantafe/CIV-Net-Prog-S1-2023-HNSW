result = 30
if result >= 50:
    # The result is 50 or above
    if result == 50:
        print("Well done")
    else:
        print("Excellent work!")
else:
    # The result is 49 or lower
    print("Unfortunately you didn't pass")
